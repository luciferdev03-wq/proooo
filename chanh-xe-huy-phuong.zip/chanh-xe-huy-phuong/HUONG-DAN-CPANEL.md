# Deploy lên cPanel (PHP) – Chành Xe Huy Phương

## Không cần Node.js

Toàn bộ API đã viết bằng **PHP + file JSON**, chạy trên shared hosting cPanel thông thường.

## Cấu trúc upload

Upload lên `public_html` (hoặc thư mục domain):

```
public_html/
├── index.html              ← Website khách
├── admin/
│   └── index.html          ← Panel admin
└── api/
    ├── _bootstrap.php
    ├── quote.php
    ├── orders.php
    ├── settings.php
    ├── test-notify.php
    ├── settings.default.json
    ├── .htaccess
    └── data/
        ├── .htaccess       ← chặn đọc file data
        └── orders.json     ← chmod 666 hoặc 775 thư mục data
```

## Quyền ghi (quan trọng)

Trong cPanel → File Manager:

1. Vào `api/data`
2. Permissions thư mục `data`: **755** hoặc **775**
3. File `orders.json`, `settings.json` (khi có): **644** hoặc **666**

Nếu form gửi nhưng không lưu đơn → gần như chắc là chưa cho PHP ghi được vào `api/data`.

## Subdomain admin (tuỳ chọn)

- `admin.tenmien.com` trỏ về thư mục `public_html/admin`
- Website vẫn dùng `https://tenmien.com/api/...`

Hoặc mở trực tiếp: `https://tenmien.com/admin/`

## Kiểm tra nhanh

1. Mở `https://tenmien.com/` → gửi form báo giá thử  
2. Mở `https://tenmien.com/admin/` → mật khẩu mặc định `huyphuong2026`  
3. Vào **Cài đặt** → điền Telegram Bot Token + Chat ID → **Gửi tin test**

## Cấu hình (config.json)

File chính: `api/config.json`

Điền token ngay trong file này **hoặc** vào Admin → Cài đặt (sẽ ghi đè vào `api/data/settings.json`).

```json
{
  "hotline": "0901.234.567",
  "hotlineRaw": "0901234567",
  "telegramBotToken": "123:ABC...",
  "telegramChatId": "123456789",
  "zaloOaAccessToken": "",
  "zaloOaAdminUserId": "",
  "zaloBotWebhookUrl": "",
  "adminPassword": "mat-khau-cua-ban"
}
```

Thứ tự đọc: `data/settings.json` (admin) → `config.json` → mặc định.

## Telegram (trên cPanel)

1. @BotFather → `/newbot` → lấy token  
2. Nhắn 1 tin cho bot  
3. Mở: `https://api.telegram.org/botTOKEN/getUpdates` → lấy `chat.id`  
4. Dán vào Admin → Cài đặt → Lưu

## Zalo OA / Zalo Bot

Điền token trong Admin → Cài đặt (giống như trước).  
Hosting cần bật **curl** (cPanel hầu hết đã bật).

## Bảo mật

- Đổi mật khẩu admin ngay trong Cài đặt  
- Không upload `server.js` / `package.json` nếu không dùng Node  
- File trong `api/data` đã chặn bằng `.htaccess`

## Lỗi thường gặp

| Hiện tượng | Cách xử lý |
|------------|------------|
| Form báo “đã gửi” nhưng admin không thấy | Chmod `api/data` cho PHP ghi được |
| CORS / fetch fail | Mở website và admin **cùng domain** |
| Telegram không về | Token/Chat ID sai, hoặc host chặn outbound HTTPS |
| 500 trên api/*.php | Bật display_errors tạm hoặc xem log cPanel |
