<?php
require __DIR__ . '/_bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = $_GET['id'] ?? null;

if ($method === 'GET') {
  // list or one
  $list = read_orders();
  if ($id) {
    foreach ($list as $o) {
      if (($o['id'] ?? '') === $id) json_out($o);
    }
    json_out(['error' => 'not_found'], 404);
  }
  json_out($list);
}

if ($method === 'PATCH' || $method === 'POST') {
  // update status: ?id=xxx  body { status: done }
  if (!$id) json_out(['error' => 'id_required'], 400);
  $body = body_json();
  $list = read_orders();
  $found = false;
  foreach ($list as &$o) {
    if (($o['id'] ?? '') === $id) {
      if (isset($body['status'])) $o['status'] = $body['status'];
      $found = true;
      $updated = $o;
      break;
    }
  }
  unset($o);
  if (!$found) json_out(['error' => 'not_found'], 404);
  write_orders($list);
  json_out($updated);
}

json_out(['error' => 'method_not_allowed'], 405);
