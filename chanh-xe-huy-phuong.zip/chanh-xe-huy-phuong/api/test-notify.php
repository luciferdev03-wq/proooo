<?php
require __DIR__ . '/_bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  json_out(['error' => 'method_not_allowed'], 405);
}
require_admin();
$s = read_settings();
$sample = [
  'id' => 'test',
  'name' => 'Test Admin',
  'phone' => $s['hotlineRaw'] ?? '0900000000',
  'service' => 'hang',
  'route' => 'daklak-sg',
  'note' => 'Tin nhắn test từ admin (cPanel PHP)',
  'createdAt' => date('c'),
];
json_out(['ok' => true, 'notify' => notify_all($sample)]);
