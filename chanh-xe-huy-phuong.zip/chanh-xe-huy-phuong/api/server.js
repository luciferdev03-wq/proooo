/**
 * Chành Xe Huy Phương – API
 * Form báo giá → Telegram + Zalo OA + Zalo Bot
 * Admin chỉnh thông tin liên hệ + token bot
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;
const DATA_FILE = path.join(__dirname, 'orders.json');
const SETTINGS_FILE = path.join(__dirname, 'settings.json');
const SETTINGS_DEFAULT = path.join(__dirname, 'settings.default.json');

app.use(cors({ origin: true }));
app.use(express.json({ limit: '1mb' }));

function readOrders() {
  try {
    if (!fs.existsSync(DATA_FILE)) return [];
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch { return []; }
}
function writeOrders(list) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2), 'utf8');
}

function readSettings() {
  try {
    let base = {};
    if (fs.existsSync(SETTINGS_DEFAULT)) {
      base = JSON.parse(fs.readFileSync(SETTINGS_DEFAULT, 'utf8'));
    }
    if (fs.existsSync(SETTINGS_FILE)) {
      const saved = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
      return { ...base, ...saved };
    }
    return base;
  } catch { return {}; }
}
function writeSettings(obj) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(obj, null, 2), 'utf8');
}

// Prefer settings.json, fallback .env
function cfg(key, envKey) {
  const s = readSettings();
  if (s[key] && String(s[key]).trim()) return String(s[key]).trim();
  if (envKey && process.env[envKey]) return process.env[envKey];
  return '';
}

function formatMessage(order) {
  const serviceMap = { hang: 'Gửi hàng hóa', xemay: 'Gửi xe máy', donnha: 'Dọn nhà / chuyển kho', khac: 'Khác' };
  const routeMap = { 'daklak-sg': 'Đắk Lắk → Sài Gòn', 'sg-daklak': 'Sài Gòn → Đắk Lắk' };
  const time = new Date(order.createdAt).toLocaleString('vi-VN');
  return [
    '🚚 *YÊU CẦU BÁO GIÁ MỚI*',
    '',
    `👤 *Họ tên:* ${order.name}`,
    `📞 *SĐT:* ${order.phone}`,
    `📦 *Dịch vụ:* ${serviceMap[order.service] || order.service}`,
    `🛣 *Tuyến:* ${routeMap[order.route] || order.route}`,
    `📝 *Ghi chú:* ${order.note || 'Không có'}`,
    `🕐 *Thời gian:* ${time}`,
    '',
    `Gọi ngay: ${order.phone}`,
  ].join('\n');
}
function formatMessagePlain(order) {
  return formatMessage(order).replace(/\*/g, '');
}

async function notifyTelegram(order) {
  const token = cfg('telegramBotToken', 'TELEGRAM_BOT_TOKEN');
  const chatId = cfg('telegramChatId', 'TELEGRAM_CHAT_ID');
  if (!token || !chatId) return { ok: false, reason: 'missing_config' };
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: formatMessage(order), parse_mode: 'Markdown', disable_web_page_preview: true }),
    });
    const data = await res.json();
    if (!data.ok) console.error('[Telegram]', data);
    return { ok: !!data.ok, data };
  } catch (e) {
    console.error('[Telegram]', e.message);
    return { ok: false, error: e.message };
  }
}

async function notifyZaloOA(order) {
  const accessToken = cfg('zaloOaAccessToken', 'ZALO_OA_ACCESS_TOKEN');
  const userId = cfg('zaloOaAdminUserId', 'ZALO_OA_ADMIN_USER_ID');
  if (!accessToken || !userId) return { ok: false, reason: 'missing_config' };
  try {
    const res = await fetch(`https://openapi.zalo.me/v3.0/oa/message/cs?access_token=${accessToken}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recipient: { user_id: userId }, message: { text: formatMessagePlain(order) } }),
    });
    const data = await res.json();
    if (data.error !== 0) console.error('[Zalo OA]', data);
    return { ok: data.error === 0, data };
  } catch (e) {
    console.error('[Zalo OA]', e.message);
    return { ok: false, error: e.message };
  }
}

async function notifyZaloBot(order) {
  const webhookUrl = cfg('zaloBotWebhookUrl', 'ZALO_BOT_WEBHOOK_URL');
  if (!webhookUrl) return { ok: false, reason: 'missing_config' };
  try {
    const res = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'quote_request', text: formatMessagePlain(order), order }),
    });
    return { ok: res.ok, status: res.status };
  } catch (e) {
    console.error('[Zalo Bot]', e.message);
    return { ok: false, error: e.message };
  }
}

async function notifyAll(order) {
  const results = await Promise.allSettled([notifyTelegram(order), notifyZaloOA(order), notifyZaloBot(order)]);
  return {
    telegram: results[0].status === 'fulfilled' ? results[0].value : { ok: false },
    zaloOA: results[1].status === 'fulfilled' ? results[1].value : { ok: false },
    zaloBot: results[2].status === 'fulfilled' ? results[2].value : { ok: false },
  };
}

app.get('/health', (_, res) => res.json({ ok: true }));

// Public: website lấy thông tin hiển thị (không trả token)
app.get('/settings/public', (req, res) => {
  const s = readSettings();
  const { telegramBotToken, telegramChatId, zaloOaAccessToken, zaloOaAdminUserId, zaloBotWebhookUrl, adminPassword, ...pub } = s;
  res.json(pub);
});

// Admin: full settings (có token) – nên bảo vệ bằng password header
app.get('/settings', (req, res) => {
  const s = readSettings();
  const pass = req.headers['x-admin-password'] || req.query.password;
  if (pass !== (s.adminPassword || 'huyphuong2026')) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  res.json(s);
});

app.put('/settings', (req, res) => {
  const current = readSettings();
  const pass = req.headers['x-admin-password'] || req.body._password;
  if (pass !== (current.adminPassword || 'huyphuong2026')) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  const allowed = [
    'siteName', 'tagline', 'hotline', 'hotlineRaw', 'email',
    'zaloOALink', 'zaloPhone', 'facebook', 'address', 'serviceArea',
    'workHours', 'workHoursNote', 'vehicle1', 'vehicle2', 'domain',
    'telegramBotToken', 'telegramChatId',
    'zaloOaAccessToken', 'zaloOaAdminUserId', 'zaloBotWebhookUrl',
    'adminPassword',
  ];
  const next = { ...current };
  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      next[key] = String(req.body[key]).trim().slice(0, key.includes('Token') || key.includes('Url') ? 500 : 300);
    }
  }
  if (req.body.hotline && !req.body.hotlineRaw) {
    next.hotlineRaw = String(req.body.hotline).replace(/\D/g, '');
  }
  writeSettings(next);
  const { telegramBotToken, zaloOaAccessToken, adminPassword, ...safe } = next;
  res.json({ ok: true, settings: { ...safe, telegramBotToken: next.telegramBotToken ? '***' : '', zaloOaAccessToken: next.zaloOaAccessToken ? '***' : '' } });
});

app.get('/orders', (req, res) => {
  const s = readSettings();
  const pass = req.headers['x-admin-password'] || req.query.password;
  if (pass && pass !== (s.adminPassword || 'huyphuong2026')) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  res.json(readOrders());
});

app.get('/orders/:id', (req, res) => {
  const order = readOrders().find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'not_found' });
  res.json(order);
});

app.patch('/orders/:id', (req, res) => {
  const list = readOrders();
  const idx = list.findIndex((o) => o.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'not_found' });
  if (req.body.status) list[idx].status = req.body.status;
  writeOrders(list);
  res.json(list[idx]);
});

app.post('/quote', async (req, res) => {
  const { name, phone, service, route, note } = req.body || {};
  if (!name || !phone) return res.status(400).json({ error: 'name_and_phone_required' });

  const order = {
    id: uuidv4(),
    name: String(name).trim().slice(0, 100),
    phone: String(phone).trim().slice(0, 20),
    service: String(service || 'hang').slice(0, 30),
    route: String(route || 'daklak-sg').slice(0, 30),
    note: String(note || '').trim().slice(0, 1000),
    status: 'new',
    createdAt: new Date().toISOString(),
  };

  const list = readOrders();
  list.push(order);
  writeOrders(list);

  const notify = await notifyAll(order);
  res.status(201).json({ ok: true, id: order.id, notify });
});

// Test notify (admin)
app.post('/test-notify', async (req, res) => {
  const s = readSettings();
  const pass = req.headers['x-admin-password'] || req.body._password;
  if (pass !== (s.adminPassword || 'huyphuong2026')) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  const sample = {
    id: 'test',
    name: 'Test Admin',
    phone: s.hotlineRaw || '0900000000',
    service: 'hang',
    route: 'daklak-sg',
    note: 'Tin nhắn test từ admin',
    createdAt: new Date().toISOString(),
  };
  const notify = await notifyAll(sample);
  res.json({ ok: true, notify });
});

app.listen(PORT, () => {
  console.log(`Huy Phương API http://localhost:${PORT}`);
});
