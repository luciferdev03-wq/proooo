<?php
require __DIR__ . '/_bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'];
$public = isset($_GET['public']);

if ($method === 'GET') {
  $s = read_settings();
  if ($public) {
    unset($s['telegramBotToken'], $s['telegramChatId'], $s['zaloOaAccessToken'], $s['zaloOaAdminUserId'], $s['zaloBotWebhookUrl'], $s['adminPassword']);
    json_out($s);
  }
  require_admin();
  json_out($s);
}

if ($method === 'PUT' || $method === 'POST') {
  require_admin();
  $current = read_settings();
  $body = body_json();
  $allowed = [
    'siteName','tagline','hotline','hotlineRaw','email',
    'zaloOALink','zaloPhone','facebook','address','serviceArea',
    'workHours','workHoursNote','vehicle1','vehicle2','domain',
    'telegramBotToken','telegramChatId',
    'zaloOaAccessToken','zaloOaAdminUserId','zaloBotWebhookUrl',
    'adminPassword',
  ];
  $next = $current;
  foreach ($allowed as $key) {
    if (array_key_exists($key, $body)) {
      $val = trim((string)$body[$key]);
      if ($key === 'adminPassword' && $val === '') continue;
      $max = (strpos($key, 'Token') !== false || strpos($key, 'Url') !== false) ? 500 : 300;
      $next[$key] = mb_substr($val, 0, $max);
    }
  }
  if (!empty($body['hotline']) && empty($body['hotlineRaw'])) {
    $next['hotlineRaw'] = preg_replace('/\D+/', '', $body['hotline']);
  }
  write_settings($next);
  json_out(['ok' => true]);
}

json_out(['error' => 'method_not_allowed'], 405);
