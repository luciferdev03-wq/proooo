<?php
require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  json_out(['error' => 'method_not_allowed'], 405);
}

$body = body_json();
$name = trim((string)($body['name'] ?? ''));
$phone = trim((string)($body['phone'] ?? ''));
if ($name === '' || $phone === '') {
  json_out(['error' => 'name_and_phone_required'], 400);
}

$order = [
  'id' => bin2hex(random_bytes(8)),
  'name' => mb_substr($name, 0, 100),
  'phone' => mb_substr($phone, 0, 20),
  'service' => mb_substr(trim((string)($body['service'] ?? 'hang')), 0, 30),
  'route' => mb_substr(trim((string)($body['route'] ?? 'daklak-sg')), 0, 30),
  'note' => mb_substr(trim((string)($body['note'] ?? '')), 0, 1000),
  'status' => 'new',
  'createdAt' => date('c'),
];

$list = read_orders();
$list[] = $order;
write_orders($list);

$notify = notify_all($order);
json_out(['ok' => true, 'id' => $order['id'], 'notify' => $notify], 201);
