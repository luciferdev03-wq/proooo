<?php
/**
 * Chành Xe Huy Phương – PHP API (cPanel)
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Password');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

define('DATA_DIR', __DIR__ . '/data');
define('ORDERS_FILE', DATA_DIR . '/orders.json');
define('SETTINGS_FILE', DATA_DIR . '/settings.json');
define('CONFIG_FILE', __DIR__ . '/config.json');
define('SETTINGS_DEFAULT', __DIR__ . '/settings.default.json');

if (!is_dir(DATA_DIR)) {
  @mkdir(DATA_DIR, 0755, true);
}

function read_json($file, $default = []) {
  if (!file_exists($file)) return $default;
  $raw = file_get_contents($file);
  $data = json_decode($raw, true);
  return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
  return file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) !== false;
}

function read_settings() {
  // Ưu tiên: data/settings.json (admin lưu) > config.json > settings.default.json
  $base = [];
  if (defined('CONFIG_FILE') && file_exists(CONFIG_FILE)) {
    $base = read_json(CONFIG_FILE, []);
  } elseif (file_exists(SETTINGS_DEFAULT)) {
    $base = read_json(SETTINGS_DEFAULT, []);
  }
  $saved = read_json(SETTINGS_FILE, []);
  return array_merge($base, $saved);
}

function write_settings($data) {
  return write_json(SETTINGS_FILE, $data);
}

function read_orders() {
  return read_json(ORDERS_FILE, []);
}

function write_orders($list) {
  return write_json(ORDERS_FILE, $list);
}

function body_json() {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function admin_password_ok() {
  $s = read_settings();
  $expected = $s['adminPassword'] ?? 'huyphuong2026';
  $pass = $_SERVER['HTTP_X_ADMIN_PASSWORD'] ?? ($_GET['password'] ?? '');
  if ($pass === '' && isset($_REQUEST['_password'])) $pass = $_REQUEST['_password'];
  $body = body_json();
  if ($pass === '' && !empty($body['_password'])) $pass = $body['_password'];
  return hash_equals((string)$expected, (string)$pass);
}

function require_admin() {
  if (!admin_password_ok()) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
  }
}

function format_message($order) {
  $serviceMap = [
    'hang' => 'Gửi hàng hóa',
    'xemay' => 'Gửi xe máy',
    'donnha' => 'Dọn nhà / chuyển kho',
    'khac' => 'Khác',
  ];
  $routeMap = [
    'daklak-sg' => 'Đắk Lắk → Sài Gòn',
    'sg-daklak' => 'Sài Gòn → Đắk Lắk',
  ];
  $svc = $serviceMap[$order['service'] ?? ''] ?? ($order['service'] ?? '');
  $route = $routeMap[$order['route'] ?? ''] ?? ($order['route'] ?? '');
  $time = date('d/m/Y H:i', strtotime($order['createdAt'] ?? 'now'));
  $note = $order['note'] ?? 'Không có';
  return "🚚 YÊU CẦU BÁO GIÁ MỚI\n\n"
    . "👤 Họ tên: {$order['name']}\n"
    . "📞 SĐT: {$order['phone']}\n"
    . "📦 Dịch vụ: {$svc}\n"
    . "🛣 Tuyến: {$route}\n"
    . "📝 Ghi chú: {$note}\n"
    . "🕐 Thời gian: {$time}\n\n"
    . "Gọi ngay: {$order['phone']}";
}

function cfg($key) {
  $s = read_settings();
  return trim((string)($s[$key] ?? ''));
}

function notify_telegram($order) {
  $token = cfg('telegramBotToken');
  $chatId = cfg('telegramChatId');
  if ($token === '' || $chatId === '') return ['ok' => false, 'reason' => 'missing_config'];

  $text = format_message($order);
  $url = "https://api.telegram.org/bot{$token}/sendMessage";
  $payload = json_encode([
    'chat_id' => $chatId,
    'text' => $text,
    'disable_web_page_preview' => true,
  ], JSON_UNESCAPED_UNICODE);

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
  ]);
  $res = curl_exec($ch);
  $err = curl_error($ch);
  curl_close($ch);
  if ($err) return ['ok' => false, 'error' => $err];
  $data = json_decode($res, true);
  return ['ok' => !empty($data['ok']), 'data' => $data];
}

function notify_zalo_oa($order) {
  $token = cfg('zaloOaAccessToken');
  $userId = cfg('zaloOaAdminUserId');
  if ($token === '' || $userId === '') return ['ok' => false, 'reason' => 'missing_config'];

  $text = format_message($order);
  $url = 'https://openapi.zalo.me/v3.0/oa/message/cs?access_token=' . urlencode($token);
  $payload = json_encode([
    'recipient' => ['user_id' => $userId],
    'message' => ['text' => $text],
  ], JSON_UNESCAPED_UNICODE);

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
  ]);
  $res = curl_exec($ch);
  $err = curl_error($ch);
  curl_close($ch);
  if ($err) return ['ok' => false, 'error' => $err];
  $data = json_decode($res, true);
  return ['ok' => isset($data['error']) && (int)$data['error'] === 0, 'data' => $data];
}

function notify_zalo_bot($order) {
  $webhook = cfg('zaloBotWebhookUrl');
  if ($webhook === '') return ['ok' => false, 'reason' => 'missing_config'];

  $payload = json_encode([
    'type' => 'quote_request',
    'text' => format_message($order),
    'order' => $order,
  ], JSON_UNESCAPED_UNICODE);

  $ch = curl_init($webhook);
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
  ]);
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err = curl_error($ch);
  curl_close($ch);
  if ($err) return ['ok' => false, 'error' => $err];
  return ['ok' => $code >= 200 && $code < 300, 'status' => $code];
}

function notify_all($order) {
  return [
    'telegram' => notify_telegram($order),
    'zaloOA' => notify_zalo_oa($order),
    'zaloBot' => notify_zalo_bot($order),
  ];
}

function json_out($data, $code = 200) {
  http_response_code($code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}
