# Hướng dẫn Admin + Thông báo Telegram / Zalo

## Cấu trúc

```
chanh-xe-huy-phuong/
├── index.html          ← Website khách (form báo giá)
├── admin/
│   └── index.html      ← Panel admin (subdomain: admin.huyphuong.vn)
└── api/
    ├── server.js       ← API nhận form + gửi thông báo
    ├── package.json
    └── .env.example    ← Copy thành .env và điền token
```

## 1. Subdomain Admin

Gợi ý DNS:

| Subdomain           | Trỏ tới                          |
|---------------------|----------------------------------|
| `huyphuong.vn`      | Thư mục website (index.html)     |
| `admin.huyphuong.vn`| Thư mục `admin/`                 |
| `api.huyphuong.vn`  | Server Node (port 3001)         |

Mật khẩu admin mặc định: **`huyphuong2026`**  
Đổi trong `admin/index.html` → biến `ADMIN_PASSWORD`.

## 2. Chạy API

```bash
cd api
cp .env.example .env
# Sửa .env cho đủ token
npm install
npm start
```

API endpoints:

- `POST /quote` – form website gửi vào đây
- `GET /orders` – admin lấy danh sách
- `PATCH /orders/:id` – đánh dấu đã xử lý

## 3. Telegram Bot (dễ nhất, nên làm trước)

1. Mở Telegram, chat với **@BotFather**
2. Gõ `/newbot` → đặt tên → nhận **token**
3. Gửi bất kỳ tin nhắn nào cho bot vừa tạo
4. Mở trình duyệt:
   ```
   https://api.telegram.org/bot<TOKEN>/getUpdates
   ```
5. Tìm `"chat":{"id": 123456789}` → đó là `TELEGRAM_CHAT_ID`
6. Điền vào `.env`:
   ```
   TELEGRAM_BOT_TOKEN=...
   TELEGRAM_CHAT_ID=...
   ```

Mỗi khi khách gửi form → bot nhắn ngay vào Telegram của bạn.

## 4. Zalo OA (Official Account)

1. Tạo / dùng OA tại https://oa.zalo.me  
2. Vào **Zalo Developers** → tạo app gắn với OA  
3. Lấy **Access Token** của OA  
4. Admin phải **quan tâm (follow)** OA trước  
5. Lấy `user_id` của admin (qua webhook `user_id` khi user quan tâm, hoặc API getfollowers)  
6. Điền `.env`:
   ```
   ZALO_OA_ACCESS_TOKEN=...
   ZALO_OA_ADMIN_USER_ID=...
   ```

API dùng endpoint gửi tin CS từ OA → user (docs Zalo Official Account API).

## 5. Zalo Bot

Zalo Bot thường chạy qua webhook / nền tảng trung gian (n8n, Make.com, server bot riêng).

Trong `.env` điền:

```
ZALO_BOT_WEBHOOK_URL=https://your-n8n-or-bot.com/webhook/huyphuong
```

API sẽ `POST` JSON:

```json
{
  "type": "quote_request",
  "text": "nội dung tin nhắn plain text",
  "order": { "id", "name", "phone", "service", "route", "note", "createdAt" }
}
```

Bạn cấu hình n8n/Make nhận webhook đó rồi đẩy sang Zalo Bot / nhóm Zalo.

## 6. Kết nối form website

Trong `index.html`, biến:

```js
const API_QUOTE_URL = 'https://api.huyphuong.vn/quote';
```

Khi chạy local: tự chuyển sang `http://localhost:3001/quote`.

Form vẫn lưu tạm vào `localStorage` nếu API lỗi, admin demo vẫn xem được.

## 7. Checklist deploy

- [ ] DNS: admin.* và api.*
- [ ] Node API chạy (PM2 / Docker / VPS)
- [ ] HTTPS cho api (Let's Encrypt)
- [ ] Telegram bot test thành công
- [ ] Zalo OA token còn hạn / refresh
- [ ] Đổi mật khẩu admin
- [ ] Đổi số hotline thật trên website

## Lưu ý

- Token Zalo OA thường có thời hạn → cần cơ chế refresh token.
- Production nên dùng database (MongoDB / PostgreSQL) thay file `orders.json`.
- Nên thêm rate-limit cho `POST /quote` chống spam.

---
Xem thêm: HUONG-DAN-CPANEL.md (deploy shared hosting PHP)

